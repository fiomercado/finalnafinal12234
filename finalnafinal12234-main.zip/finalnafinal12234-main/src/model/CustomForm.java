package model;

public class CustomForm {
}
